def main():
  x:int = 1
  y:int = 2
  z:int = x+y


if __name__ == "__main__":
  main()
