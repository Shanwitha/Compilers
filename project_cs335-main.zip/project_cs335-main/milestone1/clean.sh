#!/bin/bash

cd src && make clean
cd ..
rm -rf outputs/*
echo "rm -rf outputs/*"