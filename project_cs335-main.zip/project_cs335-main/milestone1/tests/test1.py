def main():
  x: int = 5

if __name__ == "__main__":
  main()
